const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const port = 3000;

// Nastavení pro připojení k databázi
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // Vaše uživatelské jméno pro MySQL
    password: '123',  // Vaše heslo pro MySQL
    database: 'cedaaviky'  // Název vaší databáze
});

// Připojení k databázi
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database: ', err);
        return;
    }
    console.log('Connected to the MySQL database.');
});

// Statické soubory (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// API pro získání všech produktů
app.get('/api/products', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            return res.status(500).json({ message: 'Error fetching products' });
        }
        res.json(results);
    });
});

// API pro přidání nového produktu
app.post('/api/products', (req, res) => {
    const { name, description, price } = req.body;
    db.query('INSERT INTO products (name, description, price) VALUES (?, ?, ?)', 
        [name, description, price], (err, result) => {
            if (err) {
                console.error('Error adding product:', err);
                return res.status(500).json({ message: 'Error adding product' });
            }
            res.status(201).json({ message: 'Product added successfully' });
        }
    );
});

// API pro získání všech objednávek
app.get('/api/orders', (req, res) => {
    db.query('SELECT * FROM orders', (err, results) => {
        if (err) {
            console.error('Error fetching orders:', err);
            return res.status(500).json({ message: 'Error fetching orders' });
        }
        res.json(results);
    });
});

// API pro změnu stavu objednávky
app.put('/api/orders/:id', (req, res) => {
    const { status } = req.body;
    const orderId = req.params.id;
    db.query('UPDATE orders SET status = ? WHERE id = ?', [status, orderId], (err, result) => {
        if (err) {
            console.error('Error updating order:', err);
            return res.status(500).json({ message: 'Error updating order' });
        }
        res.json({ message: 'Order status updated' });
    });
});

// Spuštění serveru
app.listen(port, () => {
    console.log(`Server běží na http://localhost:${port}`);
});
