const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const cors = require('cors');  

const app = express();
const port = 5000;  


app.use(cors());


app.use(express.json());


const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  
    password: '1234',  
    database: 'eshop'  
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database: ', err);
        return;
    }
    console.log('Connected to the MySQL database.');
});


app.use(express.static(path.join(__dirname, 'public')));


app.get('/api/products', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) {
            console.error('Error fetching products:', err);
            return res.status(500).json({ message: 'Error fetching products' });
        }
        res.json(results);
    });
});


app.post('/api/products', (req, res) => {
    const { name, description, price } = req.body;
    db.query('INSERT INTO products (name, description, price) VALUES (?, ?, ?)', 
        [name, description, price], (err, result) => {
            if (err) {
                console.error('Error adding product:', err);
                return res.status(500).json({ message: 'Error adding product' });
            }
            res.status(201).json({ message: 'Product added successfully' });
        }
    );
});


app.get('/api/orders', (req, res) => {
    db.query('SELECT * FROM orders', (err, results) => {
        if (err) {
            console.error('Error fetching orders:', err);
            return res.status(500).json({ message: 'Error fetching orders' });
        }
        res.json(results);
    });
});


app.put('/api/orders/:id', (req, res) => {
    const { status } = req.body;
    const orderId = req.params.id;
    db.query('UPDATE orders SET status = ? WHERE id = ?', [status, orderId], (err, result) => {
        if (err) {
            console.error('Error updating order:', err);
            return res.status(500).json({ message: 'Error updating order' });
        }
        res.json({ message: 'Order status updated' });
    });
});


app.listen(port, () => {
    console.log(`Server běží na http://localhost:${port}`);
});
