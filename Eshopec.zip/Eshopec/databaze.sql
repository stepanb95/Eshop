create TABLE
