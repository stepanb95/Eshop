let kosik = [];
let aktualniMena = "czk";

function koupitProdukt(id) {
    const produkt = document.getElementById(`produkt${id}`);
    const naSklade = parseInt(produkt.getAttribute("data-sklad"));

    if (naSklade > 0) {
        const cena = parseFloat(produkt.getAttribute("data-cena"));
        kosik.push({ id, cena });
        produkt.setAttribute("data-sklad", naSklade - 1);
        produkt.querySelector(".sklad").innerText = naSklade - 1;
        aktualizovatKosik();
    } else {
        alert("Produkt není skladem.");
    }
}

function aktualizovatKosik() {
    const celkovaCena = kosik.reduce((sum, p) => sum + p.cena, 0);
    document.getElementById("kosik").innerText = kosik.length + " položek";
    document.getElementById("celkova-cena").innerText = `${celkovaCena} ${aktualniMena === "czk" ? "Kč" : "€"}`;
}

function vysypatKosik() {
    kosik = [];
    aktualizovatKosik();
}

function prepnoutMeny() {
    const mena = document.getElementById("currency").value;
    aktualniMena = mena;
    document.querySelectorAll(".cena").forEach(cenaEl => {
        const cenaCZK = parseFloat(cenaEl.parentElement.parentElement.getAttribute("data-cena"));
        const novaCena = mena === "czk" ? cenaCZK : (cenaCZK / 25).toFixed(2);
        cenaEl.innerText = novaCena;
    });
    aktualizovatKosik();
}

function filterProdukty() {
    const hledat = document.querySelector(".search-bar").value.toLowerCase();
    const kategorie = document.querySelector(".category-select").value;

    document.querySelectorAll(".card").forEach(card => {
        const nazev = card.querySelector("h3").innerText.toLowerCase();
        const kategorieClass = card.classList.contains(kategorie) || !kategorie;
        const odpovida = nazev.includes(hledat) && kategorieClass;
        card.style.display = odpovida ? "block" : "none";
    });
}
